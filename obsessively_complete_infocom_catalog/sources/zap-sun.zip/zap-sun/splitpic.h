#define global_entry_size 2

#define header_len 16
#define hd_fid 0
#define hd_flags 1
#define file_flag_words_reversed 16
#define hd_local_count 4
#define hd_entry_size 8
#define hd_checksum 10

#define apple_ld_data 5
#define ld_data 8
#define ld_palette 11

