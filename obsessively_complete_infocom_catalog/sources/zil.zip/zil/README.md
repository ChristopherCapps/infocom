An early version of Infocom's ZIL compiler, written in MDL. As you see,
the files are dated no later than early 1981.

This source was originally archived at https://github.com/PDP-10/its-vault
(the `twenex/zork` directory) by Lars Brinkhoff. See also the standalone
repository at https://github.com/PDP-10/zil .

```
<ZORK.Z>APPLY.MUD.1       Mar  5  1981
<ZORK.Z>GETSTR.MUD.2      Nov  5  1979
<ZORK.Z>IBYTES.MUD.2      Oct 26  1979
<ZORK.Z>ZAC.MUD.18        Nov 13  1979
<ZORK.Z>ZAP.MUD.171       Jan 18  1980
<ZORK.Z>ZIL.MUD.176       Oct 29  1980
<ZORK.Z>ZILCH.MUD.188     Nov  3  1980
<ZORK.Z>ZIP.MUD.96        Dec 15  1979
<ZORK.Z>ZIPOUT.MUD.2      Feb 29  1980
<ZORK.Z>ZIPUTIL.MUD.3     Dec 15  1979
<ZORK.Z>ZOPS.MUD.18       Jan 17  1980
<ZORK.Z>ZSTR.MUD.2        Sep  3  1979

<ZORK.ZFTP>ZFTP.MUD.12    Jun  7  1980
```
